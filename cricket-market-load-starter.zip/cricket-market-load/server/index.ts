import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import { WebSocketServer } from 'ws';
import http from 'http';
import { snapshot, tick } from './demoFeed';

const app = express();
app.use(cors());
app.use(express.json());

const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: '/ws' });

app.get('/health', (_req, res) => res.json({ ok: true, provider: process.env.DATA_PROVIDER ?? 'demo' }));
app.get('/api/markets', (_req, res) => res.json(snapshot()));

wss.on('connection', socket => {
  socket.send(JSON.stringify(snapshot()));
});

setInterval(() => {
  const data = tick();
  const message = JSON.stringify(data);
  for (const client of wss.clients) {
    if (client.readyState === 1) client.send(message);
  }
}, 1500);

const port = Number(process.env.PORT || 8080);
server.listen(port, () => console.log(`Market feed server on http://localhost:${port}`));
