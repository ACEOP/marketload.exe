import { CricketMarket, FeedSnapshot, RunnerMarket } from './types';

const clamp = (v: number, min: number, max: number) => Math.max(min, Math.min(max, v));
const jitter = (scale: number) => (Math.random() - 0.5) * scale;
const money = (n: number) => Math.max(0, Math.round(n));

const seed = (a: string, b: string, competition: string, score: string, va: number, vb: number, oa: number, ob: number): CricketMarket => ({
  marketId: `demo-${a}-${b}`.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
  competition,
  eventName: `${a} vs ${b}`,
  score,
  statusText: 'Live',
  marketStatus: 'OPEN',
  updatedAt: new Date().toISOString(),
  runners: [
    runner(1, a, va, oa),
    runner(2, b, vb, ob),
  ],
});

const runner = (selectionId: number, name: string, totalMatched: number, ltp: number): RunnerMarket => ({
  selectionId,
  name,
  status: 'ACTIVE',
  totalMatched,
  lastPriceTraded: ltp,
  back: Number((ltp - 0.01).toFixed(2)),
  lay: Number((ltp + 0.01).toFixed(2)),
  tradedLadder: [
    { price: Number(Math.max(1.01, ltp - 0.05).toFixed(2)), size: Math.round(totalMatched * 0.10) },
    { price: Number(Math.max(1.01, ltp - 0.02).toFixed(2)), size: Math.round(totalMatched * 0.18) },
    { price: ltp, size: Math.round(totalMatched * 0.32) },
    { price: Number((ltp + 0.02).toFixed(2)), size: Math.round(totalMatched * 0.22) },
    { price: Number((ltp + 0.05).toFixed(2)), size: Math.round(totalMatched * 0.12) },
  ],
  volumeHistory: [0.72, 0.77, 0.75, 0.81, 0.84, 0.89, 0.94].map(x => Math.round(totalMatched * x)),
});

let markets: CricketMarket[] = [
  seed('South Africa', 'Australia', 'One Day Internationals', '90/0', 3_250_000, 2_550_000, 1.75, 2.30),
  seed('India', 'West Indies', 'One Day Internationals', '53/0', 29_701_112, 227_705, 1.10, 11.50),
  seed('England', 'Sri Lanka', 'One Day Internationals', '355/7', 13_201_948, 206_720, 1.06, 19.00),
  seed('Zimbabwe W', 'West Indies W', 'Women\'s One Day Internationals', '133/6', 4_677_612, 5_201_842, 1.01, 50.00),
  seed('Dolphins', 'Lions', 'South Africa T20 Challenge', '86/3', 104_529, 710_762, 4.40, 1.29),
  seed('Nigeria', 'Sierra Leone', 'T20 Matches', '51/3', 99_641, 83_523, 1.08, 4.40),
  seed('Mpumalanga Rhinos', 'Titans', 'South Africa T20 Challenge', '46/1', 96_100, 590_546, 3.05, 1.48),
  seed('Rayalaseema XI Stars', 'Godavari Golden Eagles', 'Women\'s Andhra Premier League', '15/2', 976_200, 57, 1.32, 3.80),
];

function updateRunner(r: RunnerMarket, marketTotal: number) {
  const share = r.totalMatched / Math.max(1, marketTotal);
  r.totalMatched = money(r.totalMatched * (1 + 0.004 + Math.random() * 0.010) + Math.abs(jitter(5000)));
  const drift = share > 0.75 ? jitter(0.02) : jitter(0.10);
  r.lastPriceTraded = Number(clamp(r.lastPriceTraded + drift, 1.01, 50).toFixed(2));
  r.back = Number(Math.max(1.01, r.lastPriceTraded - 0.01).toFixed(2));
  r.lay = Number((r.lastPriceTraded + 0.01).toFixed(2));
  r.tradedLadder = r.tradedLadder.map(p => ({
    price: Number(Math.max(1.01, p.price + jitter(0.01)).toFixed(2)),
    size: money(p.size * (1 + Math.random() * 0.03)),
  }));
  r.volumeHistory = [...r.volumeHistory.slice(-11), r.totalMatched];
}

export function tick(): FeedSnapshot {
  markets = markets.map(m => {
    const currentTotal = m.runners[0].totalMatched + m.runners[1].totalMatched;
    updateRunner(m.runners[0], currentTotal);
    updateRunner(m.runners[1], currentTotal);
    return { ...m, updatedAt: new Date().toISOString() };
  });
  return { provider: 'demo', markets, updatedAt: new Date().toISOString() };
}

export function snapshot(): FeedSnapshot {
  return { provider: 'demo', markets, updatedAt: new Date().toISOString() };
}
