export type MarketStatus = 'OPEN' | 'SUSPENDED' | 'CLOSED';

export interface TradedPoint {
  price: number;
  size: number;
}

export interface RunnerMarket {
  selectionId: number;
  name: string;
  status: 'ACTIVE' | 'REMOVED' | 'WINNER' | 'LOSER' | 'PLACED' | 'HIDDEN';
  totalMatched: number;
  lastPriceTraded: number;
  back: number | null;
  lay: number | null;
  tradedLadder: TradedPoint[];
  volumeHistory: number[];
}

export interface CricketMarket {
  marketId: string;
  competition: string;
  eventName: string;
  score: string;
  statusText: string;
  marketStatus: MarketStatus;
  updatedAt: string;
  runners: [RunnerMarket, RunnerMarket];
}

export interface FeedSnapshot {
  provider: 'demo' | 'betfair';
  markets: CricketMarket[];
  updatedAt: string;
}
