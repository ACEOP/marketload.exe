# Cricket Live Market Load Dashboard

A read-only cricket market-data dashboard inspired by the supplied reference screenshot. It separates the UI from the data source so a real exchange feed can replace the demo feed later.

## Current version

- Demo live matches with continuously changing market volumes/odds.
- Team percentage = team matched volume / total market matched volume × 100.
- Total market = Team A matched + Team B matched.
- Dense desktop layout + mobile responsive cards.
- Expandable rows with back/lay, traded-at-odds ladder, and volume trend.
- WebSocket transport from Node server to React client.

## Real-data plan

Use Betfair Exchange market data for exchange-level matched volume. The official Exchange Stream API exposes `EX_TRADED` (full traded ladder), `EX_TRADED_VOL` (market/runner traded volume), `EX_LTP`, and market definition updates.

Server responsibilities:
1. Authenticate with Betfair.
2. Discover active cricket `MATCH_ODDS` markets.
3. Subscribe to the required market IDs over the Exchange Stream API.
4. Normalize each runner into the app's internal `RunnerMarket` shape.
5. Broadcast normalized updates to the dashboard via WebSocket.

Keep Betfair credentials server-side only.

## Environment

Copy `.env.example` to `.env` when moving to a real feed.

## Run

```bash
npm install
npm run dev
```

Client: http://localhost:5173
Server: http://localhost:8080

## Important data distinction

`totalMatched` is money matched on the exchange. It is not the amount wagered across every sportsbook/bookmaker.
