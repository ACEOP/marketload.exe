import { useEffect, useMemo, useState } from 'react';

type Runner = { name:string; totalMatched:number; lastPriceTraded:number; back:number|null; lay:number|null; tradedLadder:{price:number;size:number}[]; volumeHistory:number[] };
type Market = { marketId:string; competition:string; eventName:string; score:string; statusText:string; marketStatus:string; updatedAt:string; runners:[Runner,Runner] };
type Snapshot = { provider:string; markets:Market[]; updatedAt:string };

const money = (n:number) => new Intl.NumberFormat('en-IN',{style:'currency',currency:'INR',maximumFractionDigits:0}).format(n);
const pct = (v:number) => `${Math.round(v)}%`;
const compact = (n:number) => n >= 1e7 ? `₹${(n/1e7).toFixed(2)} Cr` : n >= 1e5 ? `₹${(n/1e5).toFixed(2)} L` : money(n);

function Sparkline({values}:{values:number[]}) {
  const max = Math.max(...values), min = Math.min(...values);
  const w=110,h=28,p=2;
  const points=values.map((v,i)=>{
    const x=p+(i/(values.length-1||1))*(w-p*2);
    const y=max===min?h/2:h-p-((v-min)/(max-min))*(h-p*2);
    return `${x},${y}`;
  }).join(' ');
  return <svg viewBox={`0 0 ${w} ${h}`} className="spark"><polyline points={points} fill="none" stroke="currentColor" strokeWidth="2" vectorEffect="non-scaling-stroke"/></svg>;
}

function App(){
  const [data,setData]=useState<Snapshot|null>(null);
  const [expanded,setExpanded]=useState<string|null>(null);
  const [status,setStatus]=useState('Live');
  const [connected,setConnected]=useState(false);

  useEffect(()=>{
    const ws = new WebSocket(`ws://${location.host}/ws`);
    ws.onopen=()=>setConnected(true);
    ws.onclose=()=>setConnected(false);
    ws.onmessage=e=>setData(JSON.parse(e.data));
    return ()=>ws.close();
  },[]);

  const markets = useMemo(()=> (data?.markets ?? []).filter(m=>status==='All'||m.marketStatus==='OPEN'), [data,status]);
  const total = markets.reduce((s,m)=>s+m.runners[0].totalMatched+m.runners[1].totalMatched,0);
  const avgImbalance = markets.length ? markets.reduce((s,m)=>{
    const [a,b]=m.runners; const t=a.totalMatched+b.totalMatched; return s+Math.abs(a.totalMatched-b.totalMatched)/t*100;
  },0)/markets.length : 0;

  return <div className="page">
    <header className="topbar">
      <div><div className="eyebrow">CRICKET • EXCHANGE MARKET DATA</div><h1>Live market load</h1><div className="sub">Read-only market telemetry • matched volume by selection</div></div>
      <div className="feed-state"><span className={`dot ${connected?'on':'off'}`}></span>{connected?'LIVE FEED':'DISCONNECTED'}<span className="demo">{data?.provider==='demo'?'DEMO FEED':''}</span></div>
    </header>

    <section className="controls">
      <div className="select-wrap"><span>Sport</span><select><option>Cricket</option></select></div>
      <div className="select-wrap"><span>Market</span><select><option>Match Odds</option></select></div>
      <div className="seg"><button className={status==='Live'?'active':''} onClick={()=>setStatus('Live')}>Live</button><button className={status==='All'?'active':''} onClick={()=>setStatus('All')}>All</button></div>
      <div className="updated">Updated {data?new Date(data.updatedAt).toLocaleTimeString(): '—'}</div>
    </section>

    <section className="stats">
      <div><span>Live matches</span><strong>{markets.length}</strong></div>
      <div><span>Tracked matched volume</span><strong>{compact(total)}</strong></div>
      <div><span>Average imbalance</span><strong>{avgImbalance.toFixed(1)}%</strong></div>
    </section>

    <main className="list">
      {markets.map(m=>{
        const [a,b]=m.runners; const t=a.totalMatched+b.totalMatched; const ap=a.totalMatched/t*100; const bp=100-ap;
        const open=expanded===m.marketId;
        return <article key={m.marketId} className={`market ${open?'open':''}`}>
          <button className="market-head" onClick={()=>setExpanded(open?null:m.marketId)} aria-expanded={open}>
            <div className="score"><span className="live-dot"></span><b>{m.score}</b></div>
            <div className="match-info"><div className="competition">{m.competition}</div><div className="event">{m.eventName}</div><div className="live-text">{m.statusText}</div></div>
            <div className="runner-col"><div className="name">{a.name}</div><div className="amount">{compact(a.totalMatched)}</div><div className="share-pill">{pct(ap)}</div><div className="odds"><span>↗ {a.back?.toFixed(2)??'—'}</span><span>↘ {a.lay?.toFixed(2)??'—'}</span></div></div>
            <div className="runner-col"><div className="name">{b.name}</div><div className="amount">{compact(b.totalMatched)}</div><div className="share-pill">{pct(bp)}</div><div className="odds"><span>↗ {b.back?.toFixed(2)??'—'}</span><span>↘ {b.lay?.toFixed(2)??'—'}</span></div></div>
            <div className="bar"><div style={{width:`${ap}%`}}></div><div style={{width:`${bp}%`}}></div></div>
            <div className="chev">{open?'▴':'▾'}</div>
          </button>
          {open && <div className="detail">
            <div className="detail-card"><div className="detail-title">Matched at odds • {a.name}</div>{a.tradedLadder.map((p,i)=><div className="ladder" key={i}><span>{p.price.toFixed(2)}</span><span>{compact(p.size)}</span></div>)}</div>
            <div className="detail-card"><div className="detail-title">Matched at odds • {b.name}</div>{b.tradedLadder.map((p,i)=><div className="ladder" key={i}><span>{p.price.toFixed(2)}</span><span>{compact(p.size)}</span></div>)}</div>
            <div className="detail-card trend"><div className="detail-title">Volume trend</div><div className="trend-row"><div><b>{compact(a.totalMatched)}</b><span>{a.name}</span></div><Sparkline values={a.volumeHistory}/></div><div className="trend-row"><div><b>{compact(b.totalMatched)}</b><span>{b.name}</span></div><Sparkline values={b.volumeHistory}/></div></div>
          </div>}
        </article>
      })}
    </main>
    <footer>Market load is exchange-level matched volume. It does not represent all sportsbooks or bookmakers.</footer>
  </div>
}

export default App;
